import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule ,routingComponent} from './app-routing.module';
import { AppComponent } from './app.component';
import {ObjectServiceService} from './object-service.service';
import { SearchGamesPipe } from './search-games.pipe';
//import { HomeComponent } from './home/home.component';
//import { GameDetailsComponent } from './game-details/game-details.component';

@NgModule({
  declarations: [
    AppComponent,
    routingComponent,
    SearchGamesPipe,
    /*HomeComponent,
    GameDetailsComponent*/
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [ObjectServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }