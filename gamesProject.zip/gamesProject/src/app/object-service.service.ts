import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import{ BehaviorSubject } from 'rxjs/internal/BehaviorSubject';


@Injectable({
  providedIn: 'root'
})
export class ObjectServiceService {

  private messageSource =new BehaviorSubject<string>("default message");
  currentMessage=this.messageSource.asObservable()

  changeMessage(message:string){
    this.messageSource.next(message);
  }
  constructor() { }

}
