import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchGames'
})
export class SearchGamesPipe implements PipeTransform {

  isFound=false;
  fillArr = [];
  transform(items: any[], searchText: string): any[] {
    if(!items) return [];
    if(!searchText) return items;

    searchText = searchText.toLowerCase();
      return items.filter( game => {
           return game.game_name.toLowerCase().includes(searchText);
        });
   }
}