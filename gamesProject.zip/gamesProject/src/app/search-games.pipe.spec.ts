import { SearchGamesPipe } from './search-games.pipe';

describe('SearchGamesPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchGamesPipe();
    expect(pipe).toBeTruthy();
  });
});