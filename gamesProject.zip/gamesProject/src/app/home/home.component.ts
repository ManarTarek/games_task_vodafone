import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { ObjectServiceService } from "../object-service.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  constructor(
    private httpService: HttpClient,
    private router: Router,
    private myService: ObjectServiceService
  ) {}
  allCategories: string[];
  allGames: string[];
  searchText: string;
  fillArr=[];
  showGameDetails(gameObj): void {
    console.log("gameID", gameObj.game_id);
    this.myService.changeMessage(gameObj);
    localStorage.setItem("game_thumb", gameObj.game_thumb);
    localStorage.setItem("game_name", gameObj.game_name);
    localStorage.setItem("game_vendor", gameObj.game_vendor);
    localStorage.setItem("game_dev", gameObj.game_dev);
    localStorage.setItem("game_type", gameObj.game_type);
    localStorage.setItem("game_cat", gameObj.game_cat);
    localStorage.setItem("game_couter", gameObj.game_couter);
    localStorage.setItem("game_folder", gameObj.game_folder);

    this.router.navigate(["/show-game-details/", gameObj.game_id]);
  }
  /*searchGames(items: any[], searchText: string) {
    if (!items) return [];
    if (!searchText) return items;

    searchText = searchText.toLowerCase();
    return items.filter(it => {
       it.games.filter(game => {
        if(game.game_name.toLowerCase().includes(searchText)){
          console.log("found");
          this.fillArr=it;
        }
      });
      console.log("ggg",this.fillArr);

    });
  }*/

  ngOnInit() {
    this.httpService
      .get("http://api.playit.mobi/api/v1/games/getList/2/egypt")
      .subscribe(data => {
        this.allCategories = data["games_list"] as string[];
        console.log("kkkkk",this.allCategories);
      });
  }
}