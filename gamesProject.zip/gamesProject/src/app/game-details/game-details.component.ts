import { Component,OnInit, OnDestroy } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';
import {ObjectServiceService} from '../object-service.service';


@Component({
  selector: 'app-game-details',
  templateUrl: './game-details.component.html',
  styleUrls: ['./game-details.component.css']
})
export class GameDetailsComponent implements OnInit {

  message: any;
  subscription: Subscription;
  gameInfoObj:any [];
  gameName:string;
  gameThumb:string;
  gameVendor:string;
  gameDev:string;
  gameType:string;
  gameCat:string;
  gameCounter:string;
  gameFolder:string;
  constructor(private route:ActivatedRoute,private myService: ObjectServiceService) { }

  ngOnInit() {
   this.myService.currentMessage.subscribe(message =>{this.message=message;})
  this.gameName=localStorage.getItem('game_name');
  this.gameThumb=localStorage.getItem('game_thumb');
  this.gameVendor=localStorage.getItem('game_vendor');
  this.gameDev=localStorage.getItem('game_dev');
  this.gameType=localStorage.getItem('game_type');
  this.gameCat=localStorage.getItem('game_cat');
  this.gameCounter=localStorage.getItem('game_couter');
  this.gameFolder=localStorage.getItem('game_folder');

}
}

/*export class GameDetailsComponent implements OnDestroy{
    message: any;
    subscription: Subscription;

    constructor(private myService1: ObjectServiceService) {
        // subscribe to home component messages
        console.log(this.myService1.getMessage());
        this.subscription = this.myService1.getMessage().subscribe(message => { this.message = message; });
      }

    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }
}*/